"""
Nazarick Unified Addon - Tool Data
=================================

This file contains metadata about all 15 included tools.
"""

NAZARICK_TOOLS_DATA = {
    "NAZARICK_SEAM_DETAILS": {
        "name": "Nazarick Seam Details",
        "description": "Geometry modifier extracted from secrets.blend: Seam Details (218 nodes)",
        "filename": "nazarick_seam_details.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_SEAM_DETAILS_Properties', 'NAZARICK_SEAM_DETAILS_OT_add_modifier', 'NAZARICK_SEAM_DETAILS_PT_panel'],
    },
    "NAZARICK_CUT_SELECTION": {
        "name": "Nazarick Cut Selection",
        "description": "Geometry modifier extracted from secrets.blend: Cut Selection (89 nodes)",
        "filename": "nazarick_cut_selection.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_CUT_SELECTION_Properties', 'NAZARICK_CUT_SELECTION_OT_add_modifier', 'NAZARICK_CUT_SELECTION_PT_panel'],
    },
    "NAZARICK_SHADE_SEWN_DATA": {
        "name": "Nazarick Shade Sewn Data",
        "description": "Geometry modifier extracted from secrets.blend: Shade Sewn Data (26 nodes)",
        "filename": "nazarick_shade_sewn_data.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_SHADE_SEWN_DATA_Properties', 'NAZARICK_SHADE_SEWN_DATA_OT_add_modifier', 'NAZARICK_SHADE_SEWN_DATA_PT_panel'],
    },
    "NAZARICK_DISPLACE_SELECTION": {
        "name": "Nazarick Displace Selection",
        "description": "Geometry modifier extracted from secrets.blend: Displace Selection (200 nodes)",
        "filename": "nazarick_displace_selection.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_DISPLACE_SELECTION_Properties', 'NAZARICK_DISPLACE_SELECTION_OT_add_modifier', 'NAZARICK_DISPLACE_SELECTION_PT_panel'],
    },
    "NAZARICK_EDGE_DETAILS": {
        "name": "Nazarick Edge Details",
        "description": "Geometry modifier extracted from secrets.blend: Edge Details (281 nodes)",
        "filename": "nazarick_edge_details.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_EDGE_DETAILS_Properties', 'NAZARICK_EDGE_DETAILS_OT_add_modifier', 'NAZARICK_EDGE_DETAILS_PT_panel'],
    },
    "NAZARICK_DELETE_SELECTION": {
        "name": "Nazarick Delete Selection",
        "description": "Geometry modifier extracted from secrets.blend: Delete Selection (13 nodes)",
        "filename": "nazarick_delete_selection.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_DELETE_SELECTION_Properties', 'NAZARICK_DELETE_SELECTION_OT_add_modifier', 'NAZARICK_DELETE_SELECTION_PT_panel'],
    },
    "NAZARICK_NODEGROUP": {
        "name": "Nazarick NodeGroup (Top 8)",
        "description": "Complex geometry modifier extracted from secrets.blend: NodeGroup (142 nodes)",
        "filename": "nazarick_nodegroup.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_NAZARICK_NODEGROUP_Properties', 'NAZARICK_NAZARICK_NODEGROUP_OT_add_modifier', 'NAZARICK_NAZARICK_NODEGROUP_OT_recreate_nodegroup', 'NAZARICK_NAZARICK_NODEGROUP_PT_panel'],
    },
    "NAZARICK_CURVE_DETAILS": {
        "name": "Nazarick Curve Details",
        "description": "Geometry modifier extracted from secrets.blend: Curve Details (151 nodes)",
        "filename": "nazarick_curve_details.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_CURVE_DETAILS_Properties', 'NAZARICK_CURVE_DETAILS_OT_add_modifier', 'NAZARICK_CURVE_DETAILS_PT_panel'],
    },
    "NAZARICK_ATTRIBUTE_MATH": {
        "name": "Nazarick Attribute Math",
        "description": "Geometry modifier extracted from secrets.blend: Attribute Math (16 nodes)",
        "filename": "nazarick_attribute_math.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_ATTRIBUTE_MATH_Properties', 'NAZARICK_ATTRIBUTE_MATH_OT_add_modifier', 'NAZARICK_ATTRIBUTE_MATH_PT_panel'],
    },
    "NAZARICK_DENIM_TEXTURE": {
        "name": "Nazarick Denim Texture",
        "description": "Geometry modifier extracted from secrets.blend: Denim Texture (57 nodes)",
        "filename": "nazarick_denim_texture.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_DENIM_TEXTURE_Properties', 'NAZARICK_DENIM_TEXTURE_OT_add_modifier', 'NAZARICK_DENIM_TEXTURE_PT_panel'],
    },
    "NAZARICK_CUT_UV_SEAMS": {
        "name": "Nazarick Cut UV Seams",
        "description": "Geometry modifier extracted from secrets.blend: Cut UV Seams (35 nodes)",
        "filename": "nazarick_cut_uv_seams.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_CUT_UV_SEAMS_Properties', 'NAZARICK_CUT_UV_SEAMS_OT_add_modifier', 'NAZARICK_CUT_UV_SEAMS_PT_panel'],
    },
    "NAZARICK_DETAIL_THREADS": {
        "name": "Nazarick Detail Threads",
        "description": "Geometry modifier extracted from secrets.blend: Detail Threads (212 nodes)",
        "filename": "nazarick_detail_threads.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_DETAIL_THREADS_Properties', 'NAZARICK_DETAIL_THREADS_OT_add_modifier', 'NAZARICK_DETAIL_THREADS_PT_panel'],
    },
    "NAZARICK_STITCH_DETAILS": {
        "name": "Nazarick Stitch Details",
        "description": "Geometry modifier extracted from secrets.blend: Stitch Details (74 nodes)",
        "filename": "nazarick_stitch_details.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_STITCH_DETAILS_Properties', 'NAZARICK_STITCH_DETAILS_OT_add_modifier', 'NAZARICK_STITCH_DETAILS_PT_panel'],
    },
    "NAZARICK_ATTRIBUTE_TO_UV_MAP": {
        "name": "Nazarick Attribute to UV Map",
        "description": "Geometry modifier extracted from secrets.blend: Attribute to UV Map (3 nodes)",
        "filename": "nazarick_attribute_to_uv_map.py",
        "has_uv_scale": False,
        "classes": ['NAZARICK_ATTRIBUTE_TO_UV_MAP_Properties', 'NAZARICK_ATTRIBUTE_TO_UV_MAP_OT_add_modifier', 'NAZARICK_ATTRIBUTE_TO_UV_MAP_PT_panel'],
    },
    "NAZARICK_OBJECT_DETAILS": {
        "name": "Nazarick Object Details",
        "description": "Geometry modifier extracted from secrets.blend: Object Details (237 nodes)",
        "filename": "nazarick_object_details.py",
        "has_uv_scale": True,
        "classes": ['NAZARICK_OBJECT_DETAILS_Properties', 'NAZARICK_OBJECT_DETAILS_OT_add_modifier', 'NAZARICK_OBJECT_DETAILS_PT_panel'],
    },

}

TOOL_COUNT = 15
UV_ENHANCED_COUNT = 7
