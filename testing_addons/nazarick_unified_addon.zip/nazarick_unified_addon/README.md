# Nazarick Cloth Sewing Toolbox - Unified Addon

## Complete Geometry Node Collection

This unified addon contains **15 individual tools** from the Nazarick cloth sewing toolbox, all combined into a single installable package.

## Features

### ✅ Complete Toolbox
- All 15 original Nazarick geometry modifiers
- Unified interface for easy access
- Global UV ratio management
- Batch operations support

### ✅ Individual Tools Included

- **Seam Details**: Geometry modifier extracted from secrets.blend: Seam Details (218 nodes)
- **Cut Selection**: Geometry modifier extracted from secrets.blend: Cut Selection (89 nodes)
- **Shade Sewn Data**: Geometry modifier extracted from secrets.blend: Shade Sewn Data (26 nodes)
- **Displace Selection**: Geometry modifier extracted from secrets.blend: Displace Selection (200 nodes)
- **Edge Details**: Geometry modifier extracted from secrets.blend: Edge Details (281 nodes)
- **Delete Selection**: Geometry modifier extracted from secrets.blend: Delete Selection (13 nodes)
- **NodeGroup (Top 8)**: Complex geometry modifier extracted from secrets.blend: NodeGroup (142 nodes)
- **Curve Details**: Geometry modifier extracted from secrets.blend: Curve Details (151 nodes)
- **Attribute Math**: Geometry modifier extracted from secrets.blend: Attribute Math (16 nodes)
- **Denim Texture**: Geometry modifier extracted from secrets.blend: Denim Texture (57 nodes)
- **Cut UV Seams**: Geometry modifier extracted from secrets.blend: Cut UV Seams (35 nodes)
- **Detail Threads**: Geometry modifier extracted from secrets.blend: Detail Threads (212 nodes)
- **Stitch Details**: Geometry modifier extracted from secrets.blend: Stitch Details (74 nodes)
- **Attribute to UV Map**: Geometry modifier extracted from secrets.blend: Attribute to UV Map (3 nodes)
- **Object Details**: Geometry modifier extracted from secrets.blend: Object Details (237 nodes)


### ✅ Enhanced Functionality
- Global UV scale management
- Auto-calculation of UV ratios
- Unified modifier panel
- Batch application of multiple tools
- Individual tool enable/disable
- Complete original functionality preserved

## Installation

1. **Download**: Get the `nazarick_unified_addon` folder
2. **Zip**: Create a ZIP file of the entire folder
3. **Install**: In Blender, go to Edit > Preferences > Add-ons > Install...
4. **Enable**: Find "Nazarick Cloth Sewing Toolbox - Unified" and enable it

## Usage

1. **Access**: Go to Properties > Modifier Properties
2. **Panel**: Find "Nazarick Unified Toolbox" panel
3. **Select Tool**: Choose your desired tool from the dropdown
4. **Add Modifier**: Click "Add Current Tool" or use individual tool buttons
5. **Configure**: Adjust global UV settings as needed

## Advanced Features

### UV Ratio Auto-Population
- Click "Calculate UV Ratio" to auto-detect mesh-to-UV scaling
- Global UV scale affects all tools
- Auto-calculate option for streamlined workflow

### Batch Operations
- Apply multiple tools in sequence
- Enable/disable individual tools
- Streamlined workflow for complex operations

## Original Tool Compatibility

This unified addon maintains 100% compatibility with the original individual addons:
- Same geometry node groups
- Same modifier parameters
- Same functionality and behavior
- Inter-addon communication preserved

## System Requirements

- Blender 4.2.0 or higher
- Geometry Nodes support
- Compatible with cloth sewing workflows

## Support

- Documentation: https://nazarick.ai/modifiers/unified_toolbox
- Issues: Report via GitHub or Nazarick support channels
- Supreme Ruler: Ainz Ooal Gown (Nines)

---

*Extracted and unified by Demiurge for the Supreme Ruler of Nazarick*
